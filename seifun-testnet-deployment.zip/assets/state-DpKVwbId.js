import{n as r}from"./index-CU3qpmlr.js";/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */function n(t){return r({...t,state:!0,attribute:!1})}export{n as r};
