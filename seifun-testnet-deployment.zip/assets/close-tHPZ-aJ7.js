import{b as o}from"./index-COtzHjyb.js";import"./index-wmVAuaJk.js";import"./vendor-Cuqyks6h.js";import"./ethers-Ck4a2PEo.js";import"./icons-Cd5zGRfc.js";import"fs";import"path";const a=o`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M2.54 2.54a1 1 0 0 1 1.42 0L8 6.6l4.04-4.05a1 1 0 1 1 1.42 1.42L9.4 8l4.05 4.04a1 1 0 0 1-1.42 1.42L8 9.4l-4.04 4.05a1 1 0 0 1-1.42-1.42L6.6 8 2.54 3.96a1 1 0 0 1 0-1.42Z"
    clip-rule="evenodd"
  />
</svg>`;export{a as closeSvg};
