const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/add-DVapF5hJ.js","assets/index-COtzHjyb.js","assets/index-wmVAuaJk.js","assets/vendor-Cuqyks6h.js","assets/ethers-Ck4a2PEo.js","assets/icons-Cd5zGRfc.js","assets/index-eikf6_A_.css","assets/all-wallets-CT3fW6qC.js","assets/arrow-bottom-circle-D-5iyewn.js","assets/app-store-CcO6dQYa.js","assets/apple-C4H8eMI9.js","assets/arrow-bottom-C7mneVqt.js","assets/arrow-left-Bxksm7JN.js","assets/arrow-right-CA30b34t.js","assets/arrow-top-AxCjQwGV.js","assets/bank-Bi-6s_rj.js","assets/browser-C8kuYnL6.js","assets/bin-DX1mtA8C.js","assets/bitcoin-CQB4J04y.js","assets/card-Bf9DvaqX.js","assets/checkmark-ajkPYDOM.js","assets/checkmark-bold-BDT46D3B.js","assets/chevron-bottom-lbhMMrQs.js","assets/chevron-left-Drd7WWIX.js","assets/chevron-right-Cse6RQR6.js","assets/chevron-top-B1g9rBSy.js","assets/chrome-store-BW06ESNx.js","assets/clock-D2xInr7R.js","assets/close-tHPZ-aJ7.js","assets/compass-BNqL5i8q.js","assets/coinPlaceholder-B3GOgy6s.js","assets/copy-Cbi43-qw.js","assets/cursor-jfyFjGKy.js","assets/cursor-transparent-BxbInByr.js","assets/circle-BToauNRU.js","assets/desktop-DYjawuK6.js","assets/disconnect-CVcZQRAs.js","assets/discord-BuP1eayk.js","assets/ethereum-BXf9Llcm.js","assets/etherscan-BidEMpEz.js","assets/extension-BJZGYxs7.js","assets/external-link-Bn_-NiMD.js","assets/facebook-BUEr4iIx.js","assets/farcaster-Dv3qib-Y.js","assets/filters-CWTUHAi0.js","assets/github-BxI2Er5A.js","assets/google-B6amYGcN.js","assets/help-circle-BbtCxyvb.js","assets/image-DTF6MS8y.js","assets/id-BZTDjuUk.js","assets/info-circle-D72aDFNw.js","assets/lightbulb-SGhJtxPM.js","assets/mail-wiOVivsK.js","assets/mobile--p-QgJGz.js","assets/more-BZjJ3J9P.js","assets/network-placeholder-BW3QRGrd.js","assets/nftPlaceholder-BycQNVTA.js","assets/off-B9gyXgDU.js","assets/play-store-CUf7kUQm.js","assets/plus-DATNJwHj.js","assets/qr-code-BDMmDcy2.js","assets/recycle-horizontal-BjJKDgjv.js","assets/refresh-CEAFNx-a.js","assets/search-DWGsa7-V.js","assets/send-DWL1z4Ti.js","assets/swapHorizontal-D17fUX1U.js","assets/swapHorizontalMedium-CPz4R9kP.js","assets/swapHorizontalBold-BePEBRP-.js","assets/swapHorizontalRoundedBold-Bb0KHNxi.js","assets/swapVertical-CTk_wNyI.js","assets/solana-DODtBJ4I.js","assets/telegram-0RpGCAD4.js","assets/three-dots-BG3qvd6u.js","assets/twitch-zmLM1rug.js","assets/x-BS-l7JZA.js","assets/twitterIcon-B3QzE_Tb.js","assets/user-AS_H_Di6.js","assets/verify-BjfalMgS.js","assets/verify-filled-xnDh20V5.js","assets/wallet-Q6mtAbW3.js","assets/walletconnect-CRWjQXwM.js","assets/wallet-placeholder-DPMhPcIX.js","assets/warning-circle-7hwh6YMp.js","assets/info-ePjBEo3U.js","assets/exclamation-triangle-DHapKv0p.js","assets/reown-logo-RpK5KDUF.js","assets/x-mark-DnHWSaaq.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./index-wmVAuaJk.js";import{a8 as z,a9 as B,aa as T,i as P,r as R,u as M,a as I,x as S}from"./index-COtzHjyb.js";const g={getSpacingStyles(t,e){if(Array.isArray(t))return t[e]?`var(--wui-spacing-${t[e]})`:void 0;if(typeof t=="string")return`var(--wui-spacing-${t})`},getFormattedDate(t){return new Intl.DateTimeFormat("en-US",{month:"short",day:"numeric"}).format(t)},getHostName(t){try{return new URL(t).hostname}catch{return""}},getTruncateString({string:t,charsStart:e,charsEnd:i,truncate:n}){return t.length<=e+i?t:n==="end"?`${t.substring(0,e)}...`:n==="start"?`...${t.substring(t.length-i)}`:`${t.substring(0,Math.floor(e))}...${t.substring(t.length-Math.floor(i))}`},generateAvatarColors(t){const i=t.toLowerCase().replace(/^0x/iu,"").replace(/[^a-f0-9]/gu,"").substring(0,6).padEnd(6,"0"),n=this.hexToRgb(i),o=getComputedStyle(document.documentElement).getPropertyValue("--w3m-border-radius-master"),s=100-3*Number(o==null?void 0:o.replace("px","")),c=`${s}% ${s}% at 65% 40%`,_=[];for(let h=0;h<5;h+=1){const v=this.tintColor(n,.15*h);_.push(`rgb(${v[0]}, ${v[1]}, ${v[2]})`)}return`
    --local-color-1: ${_[0]};
    --local-color-2: ${_[1]};
    --local-color-3: ${_[2]};
    --local-color-4: ${_[3]};
    --local-color-5: ${_[4]};
    --local-radial-circle: ${c}
   `},hexToRgb(t){const e=parseInt(t,16),i=e>>16&255,n=e>>8&255,o=e&255;return[i,n,o]},tintColor(t,e){const[i,n,o]=t,a=Math.round(i+(255-i)*e),s=Math.round(n+(255-n)*e),c=Math.round(o+(255-o)*e);return[a,s,c]},isNumber(t){return{number:/^[0-9]+$/u}.number.test(t)},getColorTheme(t){var e;return t||(typeof window<"u"&&window.matchMedia&&typeof window.matchMedia=="function"?(e=window.matchMedia("(prefers-color-scheme: dark)"))!=null&&e.matches?"dark":"light":"dark")},splitBalance(t){const e=t.split(".");return e.length===2?[e[0],e[1]]:["0","00"]},roundNumber(t,e,i){return t.toString().length>=e?Number(t).toFixed(i):t}};function j(t,e){const{kind:i,elements:n}=e;return{kind:i,elements:n,finisher(o){customElements.get(t)||customElements.define(t,o)}}}function H(t,e){return customElements.get(t)||customElements.define(t,e),e}function L(t){return function(i){return typeof i=="function"?H(t,i):j(t,i)}}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const U={attribute:!0,type:String,converter:B,reflect:!1,hasChanged:z},G=(t=U,e,i)=>{const{kind:n,metadata:o}=i;let a=globalThis.litPropertyMetadata.get(o);if(a===void 0&&globalThis.litPropertyMetadata.set(o,a=new Map),n==="setter"&&((t=Object.create(t)).wrapped=!0),a.set(i.name,t),n==="accessor"){const{name:s}=i;return{set(c){const _=e.get.call(this);e.set.call(this,c),this.requestUpdate(s,_,t)},init(c){return c!==void 0&&this.C(s,void 0,t,c),c}}}if(n==="setter"){const{name:s}=i;return function(c){const _=this[s];e.call(this,c),this.requestUpdate(s,_,t)}}throw Error("Unsupported decorator location: "+n)};function l(t){return(e,i)=>typeof i=="object"?G(t,e,i):((n,o,a)=>{const s=o.hasOwnProperty(a);return o.constructor.createProperty(a,n),s?Object.getOwnPropertyDescriptor(o,a):void 0})(t,e,i)}/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const N=t=>t===null||typeof t!="object"&&typeof t!="function",W=t=>t.strings===void 0;/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const V={ATTRIBUTE:1,CHILD:2},C=t=>(...e)=>({_$litDirective$:t,values:e});let x=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,i,n){this._$Ct=e,this._$AM=i,this._$Ci=n}_$AS(e,i){return this.update(e,i)}update(e,i){return this.render(...i)}};/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const f=(t,e)=>{var n;const i=t._$AN;if(i===void 0)return!1;for(const o of i)(n=o._$AO)==null||n.call(o,e,!1),f(o,e);return!0},E=t=>{let e,i;do{if((e=t._$AM)===void 0)break;i=e._$AN,i.delete(t),t=e}while((i==null?void 0:i.size)===0)},k=t=>{for(let e;e=t._$AM;t=e){let i=e._$AN;if(i===void 0)e._$AN=i=new Set;else if(i.has(t))break;i.add(t),K(e)}};function F(t){this._$AN!==void 0?(E(this),this._$AM=t,k(this)):this._$AM=t}function q(t,e=!1,i=0){const n=this._$AH,o=this._$AN;if(o!==void 0&&o.size!==0)if(e)if(Array.isArray(n))for(let a=i;a<n.length;a++)f(n[a],!1),E(n[a]);else n!=null&&(f(n,!1),E(n));else f(this,t)}const K=t=>{t.type==V.CHILD&&(t._$AP??(t._$AP=q),t._$AQ??(t._$AQ=F))};class X extends x{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,i,n){super._$AT(e,i,n),k(this),this.isConnected=e._$AU}_$AO(e,i=!0){var n,o;e!==this.isConnected&&(this.isConnected=e,e?(n=this.reconnected)==null||n.call(this):(o=this.disconnected)==null||o.call(this)),i&&(f(this,e),E(this))}setValue(e){if(W(this._$Ct))this._$Ct._$AI(e,this);else{const i=[...this._$Ct._$AH];i[this._$Ci]=e,this._$Ct._$AI(i,this,0)}}disconnected(){}reconnected(){}}/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */class Y{constructor(e){this.G=e}disconnect(){this.G=void 0}reconnect(e){this.G=e}deref(){return this.G}}class Z{constructor(){this.Y=void 0,this.Z=void 0}get(){return this.Y}pause(){this.Y??(this.Y=new Promise(e=>this.Z=e))}resume(){var e;(e=this.Z)==null||e.call(this),this.Y=this.Z=void 0}}/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const O=t=>!N(t)&&typeof t.then=="function",D=1073741823;class Q extends X{constructor(){super(...arguments),this._$Cwt=D,this._$Cbt=[],this._$CK=new Y(this),this._$CX=new Z}render(...e){return e.find(i=>!O(i))??T}update(e,i){const n=this._$Cbt;let o=n.length;this._$Cbt=i;const a=this._$CK,s=this._$CX;this.isConnected||this.disconnected();for(let c=0;c<i.length&&!(c>this._$Cwt);c++){const _=i[c];if(!O(_))return this._$Cwt=c,_;c<o&&_===n[c]||(this._$Cwt=D,o=0,Promise.resolve(_).then(async h=>{for(;s.get();)await s.get();const v=a.deref();if(v!==void 0){const $=v._$Cbt.indexOf(_);$>-1&&$<v._$Cwt&&(v._$Cwt=$,v.setValue(h))}}))}return T}disconnected(){this._$CK.disconnect(),this._$CX.pause()}reconnected(){this._$CK.reconnect(this),this._$CX.resume()}}const J=C(Q);class tt{constructor(){this.cache=new Map}set(e,i){this.cache.set(e,i)}get(e){return this.cache.get(e)}has(e){return this.cache.has(e)}delete(e){this.cache.delete(e)}clear(){this.cache.clear()}}const A=new tt,et=P`
  :host {
    display: flex;
    aspect-ratio: var(--local-aspect-ratio);
    color: var(--local-color);
    width: var(--local-width);
  }

  svg {
    width: inherit;
    height: inherit;
    object-fit: contain;
    object-position: center;
  }

  .fallback {
    width: var(--local-width);
    height: var(--local-height);
  }
`;var y=function(t,e,i,n){var o=arguments.length,a=o<3?e:n===null?n=Object.getOwnPropertyDescriptor(e,i):n,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")a=Reflect.decorate(t,e,i,n);else for(var c=t.length-1;c>=0;c--)(s=t[c])&&(a=(o<3?s(a):o>3?s(e,i,a):s(e,i))||a);return o>3&&a&&Object.defineProperty(e,i,a),a};const b={add:async()=>(await r(async()=>{const{addSvg:t}=await import("./add-DVapF5hJ.js");return{addSvg:t}},__vite__mapDeps([0,1,2,3,4,5,6]))).addSvg,allWallets:async()=>(await r(async()=>{const{allWalletsSvg:t}=await import("./all-wallets-CT3fW6qC.js");return{allWalletsSvg:t}},__vite__mapDeps([7,1,2,3,4,5,6]))).allWalletsSvg,arrowBottomCircle:async()=>(await r(async()=>{const{arrowBottomCircleSvg:t}=await import("./arrow-bottom-circle-D-5iyewn.js");return{arrowBottomCircleSvg:t}},__vite__mapDeps([8,1,2,3,4,5,6]))).arrowBottomCircleSvg,appStore:async()=>(await r(async()=>{const{appStoreSvg:t}=await import("./app-store-CcO6dQYa.js");return{appStoreSvg:t}},__vite__mapDeps([9,1,2,3,4,5,6]))).appStoreSvg,apple:async()=>(await r(async()=>{const{appleSvg:t}=await import("./apple-C4H8eMI9.js");return{appleSvg:t}},__vite__mapDeps([10,1,2,3,4,5,6]))).appleSvg,arrowBottom:async()=>(await r(async()=>{const{arrowBottomSvg:t}=await import("./arrow-bottom-C7mneVqt.js");return{arrowBottomSvg:t}},__vite__mapDeps([11,1,2,3,4,5,6]))).arrowBottomSvg,arrowLeft:async()=>(await r(async()=>{const{arrowLeftSvg:t}=await import("./arrow-left-Bxksm7JN.js");return{arrowLeftSvg:t}},__vite__mapDeps([12,1,2,3,4,5,6]))).arrowLeftSvg,arrowRight:async()=>(await r(async()=>{const{arrowRightSvg:t}=await import("./arrow-right-CA30b34t.js");return{arrowRightSvg:t}},__vite__mapDeps([13,1,2,3,4,5,6]))).arrowRightSvg,arrowTop:async()=>(await r(async()=>{const{arrowTopSvg:t}=await import("./arrow-top-AxCjQwGV.js");return{arrowTopSvg:t}},__vite__mapDeps([14,1,2,3,4,5,6]))).arrowTopSvg,bank:async()=>(await r(async()=>{const{bankSvg:t}=await import("./bank-Bi-6s_rj.js");return{bankSvg:t}},__vite__mapDeps([15,1,2,3,4,5,6]))).bankSvg,browser:async()=>(await r(async()=>{const{browserSvg:t}=await import("./browser-C8kuYnL6.js");return{browserSvg:t}},__vite__mapDeps([16,1,2,3,4,5,6]))).browserSvg,bin:async()=>(await r(async()=>{const{binSvg:t}=await import("./bin-DX1mtA8C.js");return{binSvg:t}},__vite__mapDeps([17,1,2,3,4,5,6]))).binSvg,bitcoin:async()=>(await r(async()=>{const{bitcoinSvg:t}=await import("./bitcoin-CQB4J04y.js");return{bitcoinSvg:t}},__vite__mapDeps([18,1,2,3,4,5,6]))).bitcoinSvg,card:async()=>(await r(async()=>{const{cardSvg:t}=await import("./card-Bf9DvaqX.js");return{cardSvg:t}},__vite__mapDeps([19,1,2,3,4,5,6]))).cardSvg,checkmark:async()=>(await r(async()=>{const{checkmarkSvg:t}=await import("./checkmark-ajkPYDOM.js");return{checkmarkSvg:t}},__vite__mapDeps([20,1,2,3,4,5,6]))).checkmarkSvg,checkmarkBold:async()=>(await r(async()=>{const{checkmarkBoldSvg:t}=await import("./checkmark-bold-BDT46D3B.js");return{checkmarkBoldSvg:t}},__vite__mapDeps([21,1,2,3,4,5,6]))).checkmarkBoldSvg,chevronBottom:async()=>(await r(async()=>{const{chevronBottomSvg:t}=await import("./chevron-bottom-lbhMMrQs.js");return{chevronBottomSvg:t}},__vite__mapDeps([22,1,2,3,4,5,6]))).chevronBottomSvg,chevronLeft:async()=>(await r(async()=>{const{chevronLeftSvg:t}=await import("./chevron-left-Drd7WWIX.js");return{chevronLeftSvg:t}},__vite__mapDeps([23,1,2,3,4,5,6]))).chevronLeftSvg,chevronRight:async()=>(await r(async()=>{const{chevronRightSvg:t}=await import("./chevron-right-Cse6RQR6.js");return{chevronRightSvg:t}},__vite__mapDeps([24,1,2,3,4,5,6]))).chevronRightSvg,chevronTop:async()=>(await r(async()=>{const{chevronTopSvg:t}=await import("./chevron-top-B1g9rBSy.js");return{chevronTopSvg:t}},__vite__mapDeps([25,1,2,3,4,5,6]))).chevronTopSvg,chromeStore:async()=>(await r(async()=>{const{chromeStoreSvg:t}=await import("./chrome-store-BW06ESNx.js");return{chromeStoreSvg:t}},__vite__mapDeps([26,1,2,3,4,5,6]))).chromeStoreSvg,clock:async()=>(await r(async()=>{const{clockSvg:t}=await import("./clock-D2xInr7R.js");return{clockSvg:t}},__vite__mapDeps([27,1,2,3,4,5,6]))).clockSvg,close:async()=>(await r(async()=>{const{closeSvg:t}=await import("./close-tHPZ-aJ7.js");return{closeSvg:t}},__vite__mapDeps([28,1,2,3,4,5,6]))).closeSvg,compass:async()=>(await r(async()=>{const{compassSvg:t}=await import("./compass-BNqL5i8q.js");return{compassSvg:t}},__vite__mapDeps([29,1,2,3,4,5,6]))).compassSvg,coinPlaceholder:async()=>(await r(async()=>{const{coinPlaceholderSvg:t}=await import("./coinPlaceholder-B3GOgy6s.js");return{coinPlaceholderSvg:t}},__vite__mapDeps([30,1,2,3,4,5,6]))).coinPlaceholderSvg,copy:async()=>(await r(async()=>{const{copySvg:t}=await import("./copy-Cbi43-qw.js");return{copySvg:t}},__vite__mapDeps([31,1,2,3,4,5,6]))).copySvg,cursor:async()=>(await r(async()=>{const{cursorSvg:t}=await import("./cursor-jfyFjGKy.js");return{cursorSvg:t}},__vite__mapDeps([32,1,2,3,4,5,6]))).cursorSvg,cursorTransparent:async()=>(await r(async()=>{const{cursorTransparentSvg:t}=await import("./cursor-transparent-BxbInByr.js");return{cursorTransparentSvg:t}},__vite__mapDeps([33,1,2,3,4,5,6]))).cursorTransparentSvg,circle:async()=>(await r(async()=>{const{circleSvg:t}=await import("./circle-BToauNRU.js");return{circleSvg:t}},__vite__mapDeps([34,1,2,3,4,5,6]))).circleSvg,desktop:async()=>(await r(async()=>{const{desktopSvg:t}=await import("./desktop-DYjawuK6.js");return{desktopSvg:t}},__vite__mapDeps([35,1,2,3,4,5,6]))).desktopSvg,disconnect:async()=>(await r(async()=>{const{disconnectSvg:t}=await import("./disconnect-CVcZQRAs.js");return{disconnectSvg:t}},__vite__mapDeps([36,1,2,3,4,5,6]))).disconnectSvg,discord:async()=>(await r(async()=>{const{discordSvg:t}=await import("./discord-BuP1eayk.js");return{discordSvg:t}},__vite__mapDeps([37,1,2,3,4,5,6]))).discordSvg,ethereum:async()=>(await r(async()=>{const{ethereumSvg:t}=await import("./ethereum-BXf9Llcm.js");return{ethereumSvg:t}},__vite__mapDeps([38,1,2,3,4,5,6]))).ethereumSvg,etherscan:async()=>(await r(async()=>{const{etherscanSvg:t}=await import("./etherscan-BidEMpEz.js");return{etherscanSvg:t}},__vite__mapDeps([39,1,2,3,4,5,6]))).etherscanSvg,extension:async()=>(await r(async()=>{const{extensionSvg:t}=await import("./extension-BJZGYxs7.js");return{extensionSvg:t}},__vite__mapDeps([40,1,2,3,4,5,6]))).extensionSvg,externalLink:async()=>(await r(async()=>{const{externalLinkSvg:t}=await import("./external-link-Bn_-NiMD.js");return{externalLinkSvg:t}},__vite__mapDeps([41,1,2,3,4,5,6]))).externalLinkSvg,facebook:async()=>(await r(async()=>{const{facebookSvg:t}=await import("./facebook-BUEr4iIx.js");return{facebookSvg:t}},__vite__mapDeps([42,1,2,3,4,5,6]))).facebookSvg,farcaster:async()=>(await r(async()=>{const{farcasterSvg:t}=await import("./farcaster-Dv3qib-Y.js");return{farcasterSvg:t}},__vite__mapDeps([43,1,2,3,4,5,6]))).farcasterSvg,filters:async()=>(await r(async()=>{const{filtersSvg:t}=await import("./filters-CWTUHAi0.js");return{filtersSvg:t}},__vite__mapDeps([44,1,2,3,4,5,6]))).filtersSvg,github:async()=>(await r(async()=>{const{githubSvg:t}=await import("./github-BxI2Er5A.js");return{githubSvg:t}},__vite__mapDeps([45,1,2,3,4,5,6]))).githubSvg,google:async()=>(await r(async()=>{const{googleSvg:t}=await import("./google-B6amYGcN.js");return{googleSvg:t}},__vite__mapDeps([46,1,2,3,4,5,6]))).googleSvg,helpCircle:async()=>(await r(async()=>{const{helpCircleSvg:t}=await import("./help-circle-BbtCxyvb.js");return{helpCircleSvg:t}},__vite__mapDeps([47,1,2,3,4,5,6]))).helpCircleSvg,image:async()=>(await r(async()=>{const{imageSvg:t}=await import("./image-DTF6MS8y.js");return{imageSvg:t}},__vite__mapDeps([48,1,2,3,4,5,6]))).imageSvg,id:async()=>(await r(async()=>{const{idSvg:t}=await import("./id-BZTDjuUk.js");return{idSvg:t}},__vite__mapDeps([49,1,2,3,4,5,6]))).idSvg,infoCircle:async()=>(await r(async()=>{const{infoCircleSvg:t}=await import("./info-circle-D72aDFNw.js");return{infoCircleSvg:t}},__vite__mapDeps([50,1,2,3,4,5,6]))).infoCircleSvg,lightbulb:async()=>(await r(async()=>{const{lightbulbSvg:t}=await import("./lightbulb-SGhJtxPM.js");return{lightbulbSvg:t}},__vite__mapDeps([51,1,2,3,4,5,6]))).lightbulbSvg,mail:async()=>(await r(async()=>{const{mailSvg:t}=await import("./mail-wiOVivsK.js");return{mailSvg:t}},__vite__mapDeps([52,1,2,3,4,5,6]))).mailSvg,mobile:async()=>(await r(async()=>{const{mobileSvg:t}=await import("./mobile--p-QgJGz.js");return{mobileSvg:t}},__vite__mapDeps([53,1,2,3,4,5,6]))).mobileSvg,more:async()=>(await r(async()=>{const{moreSvg:t}=await import("./more-BZjJ3J9P.js");return{moreSvg:t}},__vite__mapDeps([54,1,2,3,4,5,6]))).moreSvg,networkPlaceholder:async()=>(await r(async()=>{const{networkPlaceholderSvg:t}=await import("./network-placeholder-BW3QRGrd.js");return{networkPlaceholderSvg:t}},__vite__mapDeps([55,1,2,3,4,5,6]))).networkPlaceholderSvg,nftPlaceholder:async()=>(await r(async()=>{const{nftPlaceholderSvg:t}=await import("./nftPlaceholder-BycQNVTA.js");return{nftPlaceholderSvg:t}},__vite__mapDeps([56,1,2,3,4,5,6]))).nftPlaceholderSvg,off:async()=>(await r(async()=>{const{offSvg:t}=await import("./off-B9gyXgDU.js");return{offSvg:t}},__vite__mapDeps([57,1,2,3,4,5,6]))).offSvg,playStore:async()=>(await r(async()=>{const{playStoreSvg:t}=await import("./play-store-CUf7kUQm.js");return{playStoreSvg:t}},__vite__mapDeps([58,1,2,3,4,5,6]))).playStoreSvg,plus:async()=>(await r(async()=>{const{plusSvg:t}=await import("./plus-DATNJwHj.js");return{plusSvg:t}},__vite__mapDeps([59,1,2,3,4,5,6]))).plusSvg,qrCode:async()=>(await r(async()=>{const{qrCodeIcon:t}=await import("./qr-code-BDMmDcy2.js");return{qrCodeIcon:t}},__vite__mapDeps([60,1,2,3,4,5,6]))).qrCodeIcon,recycleHorizontal:async()=>(await r(async()=>{const{recycleHorizontalSvg:t}=await import("./recycle-horizontal-BjJKDgjv.js");return{recycleHorizontalSvg:t}},__vite__mapDeps([61,1,2,3,4,5,6]))).recycleHorizontalSvg,refresh:async()=>(await r(async()=>{const{refreshSvg:t}=await import("./refresh-CEAFNx-a.js");return{refreshSvg:t}},__vite__mapDeps([62,1,2,3,4,5,6]))).refreshSvg,search:async()=>(await r(async()=>{const{searchSvg:t}=await import("./search-DWGsa7-V.js");return{searchSvg:t}},__vite__mapDeps([63,1,2,3,4,5,6]))).searchSvg,send:async()=>(await r(async()=>{const{sendSvg:t}=await import("./send-DWL1z4Ti.js");return{sendSvg:t}},__vite__mapDeps([64,1,2,3,4,5,6]))).sendSvg,swapHorizontal:async()=>(await r(async()=>{const{swapHorizontalSvg:t}=await import("./swapHorizontal-D17fUX1U.js");return{swapHorizontalSvg:t}},__vite__mapDeps([65,1,2,3,4,5,6]))).swapHorizontalSvg,swapHorizontalMedium:async()=>(await r(async()=>{const{swapHorizontalMediumSvg:t}=await import("./swapHorizontalMedium-CPz4R9kP.js");return{swapHorizontalMediumSvg:t}},__vite__mapDeps([66,1,2,3,4,5,6]))).swapHorizontalMediumSvg,swapHorizontalBold:async()=>(await r(async()=>{const{swapHorizontalBoldSvg:t}=await import("./swapHorizontalBold-BePEBRP-.js");return{swapHorizontalBoldSvg:t}},__vite__mapDeps([67,1,2,3,4,5,6]))).swapHorizontalBoldSvg,swapHorizontalRoundedBold:async()=>(await r(async()=>{const{swapHorizontalRoundedBoldSvg:t}=await import("./swapHorizontalRoundedBold-Bb0KHNxi.js");return{swapHorizontalRoundedBoldSvg:t}},__vite__mapDeps([68,1,2,3,4,5,6]))).swapHorizontalRoundedBoldSvg,swapVertical:async()=>(await r(async()=>{const{swapVerticalSvg:t}=await import("./swapVertical-CTk_wNyI.js");return{swapVerticalSvg:t}},__vite__mapDeps([69,1,2,3,4,5,6]))).swapVerticalSvg,solana:async()=>(await r(async()=>{const{solanaSvg:t}=await import("./solana-DODtBJ4I.js");return{solanaSvg:t}},__vite__mapDeps([70,1,2,3,4,5,6]))).solanaSvg,telegram:async()=>(await r(async()=>{const{telegramSvg:t}=await import("./telegram-0RpGCAD4.js");return{telegramSvg:t}},__vite__mapDeps([71,1,2,3,4,5,6]))).telegramSvg,threeDots:async()=>(await r(async()=>{const{threeDotsSvg:t}=await import("./three-dots-BG3qvd6u.js");return{threeDotsSvg:t}},__vite__mapDeps([72,1,2,3,4,5,6]))).threeDotsSvg,twitch:async()=>(await r(async()=>{const{twitchSvg:t}=await import("./twitch-zmLM1rug.js");return{twitchSvg:t}},__vite__mapDeps([73,1,2,3,4,5,6]))).twitchSvg,twitter:async()=>(await r(async()=>{const{xSvg:t}=await import("./x-BS-l7JZA.js");return{xSvg:t}},__vite__mapDeps([74,1,2,3,4,5,6]))).xSvg,twitterIcon:async()=>(await r(async()=>{const{twitterIconSvg:t}=await import("./twitterIcon-B3QzE_Tb.js");return{twitterIconSvg:t}},__vite__mapDeps([75,1,2,3,4,5,6]))).twitterIconSvg,user:async()=>(await r(async()=>{const{userSvg:t}=await import("./user-AS_H_Di6.js");return{userSvg:t}},__vite__mapDeps([76,1,2,3,4,5,6]))).userSvg,verify:async()=>(await r(async()=>{const{verifySvg:t}=await import("./verify-BjfalMgS.js");return{verifySvg:t}},__vite__mapDeps([77,1,2,3,4,5,6]))).verifySvg,verifyFilled:async()=>(await r(async()=>{const{verifyFilledSvg:t}=await import("./verify-filled-xnDh20V5.js");return{verifyFilledSvg:t}},__vite__mapDeps([78,1,2,3,4,5,6]))).verifyFilledSvg,wallet:async()=>(await r(async()=>{const{walletSvg:t}=await import("./wallet-Q6mtAbW3.js");return{walletSvg:t}},__vite__mapDeps([79,1,2,3,4,5,6]))).walletSvg,walletConnect:async()=>(await r(async()=>{const{walletConnectSvg:t}=await import("./walletconnect-CRWjQXwM.js");return{walletConnectSvg:t}},__vite__mapDeps([80,1,2,3,4,5,6]))).walletConnectSvg,walletConnectLightBrown:async()=>(await r(async()=>{const{walletConnectLightBrownSvg:t}=await import("./walletconnect-CRWjQXwM.js");return{walletConnectLightBrownSvg:t}},__vite__mapDeps([80,1,2,3,4,5,6]))).walletConnectLightBrownSvg,walletConnectBrown:async()=>(await r(async()=>{const{walletConnectBrownSvg:t}=await import("./walletconnect-CRWjQXwM.js");return{walletConnectBrownSvg:t}},__vite__mapDeps([80,1,2,3,4,5,6]))).walletConnectBrownSvg,walletPlaceholder:async()=>(await r(async()=>{const{walletPlaceholderSvg:t}=await import("./wallet-placeholder-DPMhPcIX.js");return{walletPlaceholderSvg:t}},__vite__mapDeps([81,1,2,3,4,5,6]))).walletPlaceholderSvg,warningCircle:async()=>(await r(async()=>{const{warningCircleSvg:t}=await import("./warning-circle-7hwh6YMp.js");return{warningCircleSvg:t}},__vite__mapDeps([82,1,2,3,4,5,6]))).warningCircleSvg,x:async()=>(await r(async()=>{const{xSvg:t}=await import("./x-BS-l7JZA.js");return{xSvg:t}},__vite__mapDeps([74,1,2,3,4,5,6]))).xSvg,info:async()=>(await r(async()=>{const{infoSvg:t}=await import("./info-ePjBEo3U.js");return{infoSvg:t}},__vite__mapDeps([83,1,2,3,4,5,6]))).infoSvg,exclamationTriangle:async()=>(await r(async()=>{const{exclamationTriangleSvg:t}=await import("./exclamation-triangle-DHapKv0p.js");return{exclamationTriangleSvg:t}},__vite__mapDeps([84,1,2,3,4,5,6]))).exclamationTriangleSvg,reown:async()=>(await r(async()=>{const{reownSvg:t}=await import("./reown-logo-RpK5KDUF.js");return{reownSvg:t}},__vite__mapDeps([85,1,2,3,4,5,6]))).reownSvg,"x-mark":async()=>(await r(async()=>{const{xMarkSvg:t}=await import("./x-mark-DnHWSaaq.js");return{xMarkSvg:t}},__vite__mapDeps([86,1,2,3,4,5,6]))).xMarkSvg};async function it(t){if(A.has(t))return A.get(t);const i=(b[t]??b.copy)();return A.set(t,i),i}let d=class extends I{constructor(){super(...arguments),this.size="md",this.name="copy",this.color="fg-300",this.aspectRatio="1 / 1"}render(){return this.style.cssText=`
      --local-color: ${`var(--wui-color-${this.color});`}
      --local-width: ${`var(--wui-icon-size-${this.size});`}
      --local-aspect-ratio: ${this.aspectRatio}
    `,S`${J(it(this.name),S`<div class="fallback"></div>`)}`}};d.styles=[R,M,et];y([l()],d.prototype,"size",void 0);y([l()],d.prototype,"name",void 0);y([l()],d.prototype,"color",void 0);y([l()],d.prototype,"aspectRatio",void 0);d=y([L("wui-icon")],d);/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const rt=C(class extends x{constructor(t){var e;if(super(t),t.type!==V.ATTRIBUTE||t.name!=="class"||((e=t.strings)==null?void 0:e.length)>2)throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.")}render(t){return" "+Object.keys(t).filter(e=>t[e]).join(" ")+" "}update(t,[e]){var n,o;if(this.st===void 0){this.st=new Set,t.strings!==void 0&&(this.nt=new Set(t.strings.join(" ").split(/\s/).filter(a=>a!=="")));for(const a in e)e[a]&&!((n=this.nt)!=null&&n.has(a))&&this.st.add(a);return this.render(e)}const i=t.element.classList;for(const a of this.st)a in e||(i.remove(a),this.st.delete(a));for(const a in e){const s=!!e[a];s===this.st.has(a)||(o=this.nt)!=null&&o.has(a)||(s?(i.add(a),this.st.add(a)):(i.remove(a),this.st.delete(a)))}return T}}),at=P`
  :host {
    display: inline-flex !important;
  }

  slot {
    width: 100%;
    display: inline-block;
    font-style: normal;
    font-family: var(--wui-font-family);
    font-feature-settings:
      'tnum' on,
      'lnum' on,
      'case' on;
    line-height: 130%;
    font-weight: var(--wui-font-weight-regular);
    overflow: inherit;
    text-overflow: inherit;
    text-align: var(--local-align);
    color: var(--local-color);
  }

  .wui-line-clamp-1 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
  }

  .wui-line-clamp-2 {
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .wui-font-medium-400 {
    font-size: var(--wui-font-size-medium);
    font-weight: var(--wui-font-weight-light);
    letter-spacing: var(--wui-letter-spacing-medium);
  }

  .wui-font-medium-600 {
    font-size: var(--wui-font-size-medium);
    letter-spacing: var(--wui-letter-spacing-medium);
  }

  .wui-font-title-600 {
    font-size: var(--wui-font-size-title);
    letter-spacing: var(--wui-letter-spacing-title);
  }

  .wui-font-title-6-600 {
    font-size: var(--wui-font-size-title-6);
    letter-spacing: var(--wui-letter-spacing-title-6);
  }

  .wui-font-mini-700 {
    font-size: var(--wui-font-size-mini);
    letter-spacing: var(--wui-letter-spacing-mini);
    text-transform: uppercase;
  }

  .wui-font-large-500,
  .wui-font-large-600,
  .wui-font-large-700 {
    font-size: var(--wui-font-size-large);
    letter-spacing: var(--wui-letter-spacing-large);
  }

  .wui-font-2xl-500,
  .wui-font-2xl-600,
  .wui-font-2xl-700 {
    font-size: var(--wui-font-size-2xl);
    letter-spacing: var(--wui-letter-spacing-2xl);
  }

  .wui-font-paragraph-400,
  .wui-font-paragraph-500,
  .wui-font-paragraph-600,
  .wui-font-paragraph-700 {
    font-size: var(--wui-font-size-paragraph);
    letter-spacing: var(--wui-letter-spacing-paragraph);
  }

  .wui-font-small-400,
  .wui-font-small-500,
  .wui-font-small-600 {
    font-size: var(--wui-font-size-small);
    letter-spacing: var(--wui-letter-spacing-small);
  }

  .wui-font-tiny-400,
  .wui-font-tiny-500,
  .wui-font-tiny-600 {
    font-size: var(--wui-font-size-tiny);
    letter-spacing: var(--wui-letter-spacing-tiny);
  }

  .wui-font-micro-700,
  .wui-font-micro-600,
  .wui-font-micro-500 {
    font-size: var(--wui-font-size-micro);
    letter-spacing: var(--wui-letter-spacing-micro);
    text-transform: uppercase;
  }

  .wui-font-tiny-400,
  .wui-font-small-400,
  .wui-font-medium-400,
  .wui-font-paragraph-400 {
    font-weight: var(--wui-font-weight-light);
  }

  .wui-font-large-700,
  .wui-font-paragraph-700,
  .wui-font-micro-700,
  .wui-font-mini-700 {
    font-weight: var(--wui-font-weight-bold);
  }

  .wui-font-medium-600,
  .wui-font-medium-title-600,
  .wui-font-title-6-600,
  .wui-font-large-600,
  .wui-font-paragraph-600,
  .wui-font-small-600,
  .wui-font-tiny-600,
  .wui-font-micro-600 {
    font-weight: var(--wui-font-weight-medium);
  }

  :host([disabled]) {
    opacity: 0.4;
  }
`;var m=function(t,e,i,n){var o=arguments.length,a=o<3?e:n===null?n=Object.getOwnPropertyDescriptor(e,i):n,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")a=Reflect.decorate(t,e,i,n);else for(var c=t.length-1;c>=0;c--)(s=t[c])&&(a=(o<3?s(a):o>3?s(e,i,a):s(e,i))||a);return o>3&&a&&Object.defineProperty(e,i,a),a};let p=class extends I{constructor(){super(...arguments),this.variant="paragraph-500",this.color="fg-300",this.align="left",this.lineClamp=void 0}render(){const e={[`wui-font-${this.variant}`]:!0,[`wui-color-${this.color}`]:!0,[`wui-line-clamp-${this.lineClamp}`]:!!this.lineClamp};return this.style.cssText=`
      --local-align: ${this.align};
      --local-color: var(--wui-color-${this.color});
    `,S`<slot class=${rt(e)}></slot>`}};p.styles=[R,at];m([l()],p.prototype,"variant",void 0);m([l()],p.prototype,"color",void 0);m([l()],p.prototype,"align",void 0);m([l()],p.prototype,"lineClamp",void 0);p=m([L("wui-text")],p);const nt=P`
  :host {
    display: flex;
    width: inherit;
    height: inherit;
  }
`;var w=function(t,e,i,n){var o=arguments.length,a=o<3?e:n===null?n=Object.getOwnPropertyDescriptor(e,i):n,s;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")a=Reflect.decorate(t,e,i,n);else for(var c=t.length-1;c>=0;c--)(s=t[c])&&(a=(o<3?s(a):o>3?s(e,i,a):s(e,i))||a);return o>3&&a&&Object.defineProperty(e,i,a),a};let u=class extends I{render(){return this.style.cssText=`
      flex-direction: ${this.flexDirection};
      flex-wrap: ${this.flexWrap};
      flex-basis: ${this.flexBasis};
      flex-grow: ${this.flexGrow};
      flex-shrink: ${this.flexShrink};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      column-gap: ${this.columnGap&&`var(--wui-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap&&`var(--wui-spacing-${this.rowGap})`};
      gap: ${this.gap&&`var(--wui-spacing-${this.gap})`};
      padding-top: ${this.padding&&g.getSpacingStyles(this.padding,0)};
      padding-right: ${this.padding&&g.getSpacingStyles(this.padding,1)};
      padding-bottom: ${this.padding&&g.getSpacingStyles(this.padding,2)};
      padding-left: ${this.padding&&g.getSpacingStyles(this.padding,3)};
      margin-top: ${this.margin&&g.getSpacingStyles(this.margin,0)};
      margin-right: ${this.margin&&g.getSpacingStyles(this.margin,1)};
      margin-bottom: ${this.margin&&g.getSpacingStyles(this.margin,2)};
      margin-left: ${this.margin&&g.getSpacingStyles(this.margin,3)};
    `,S`<slot></slot>`}};u.styles=[R,nt];w([l()],u.prototype,"flexDirection",void 0);w([l()],u.prototype,"flexWrap",void 0);w([l()],u.prototype,"flexBasis",void 0);w([l()],u.prototype,"flexGrow",void 0);w([l()],u.prototype,"flexShrink",void 0);w([l()],u.prototype,"alignItems",void 0);w([l()],u.prototype,"justifyContent",void 0);w([l()],u.prototype,"columnGap",void 0);w([l()],u.prototype,"rowGap",void 0);w([l()],u.prototype,"gap",void 0);w([l()],u.prototype,"padding",void 0);w([l()],u.prototype,"margin",void 0);u=w([L("wui-flex")],u);export{g as U,rt as a,L as c,C as e,X as f,l as n};
