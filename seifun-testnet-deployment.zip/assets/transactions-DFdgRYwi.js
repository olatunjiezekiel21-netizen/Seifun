import{i as c,a as s,x as f}from"./state-pA-L5z5-.js";import"./index-COtzHjyb.js";import{c as a}from"./index-CU3qpmlr.js";import"./index-B5u4p1-w.js";import"./index-wmVAuaJk.js";import"./vendor-Cuqyks6h.js";import"./ethers-Ck4a2PEo.js";import"./icons-Cd5zGRfc.js";import"fs";import"path";import"./index-F1uHDXOZ.js";import"./index-BnKu835Y.js";import"./if-defined-CaE3CB5O.js";import"./index-tv5L8SGK.js";import"./index-DLH5T5nC.js";const d=c`
  :host > wui-flex:first-child {
    height: 500px;
    overflow-y: auto;
    overflow-x: hidden;
    scrollbar-width: none;
  }

  :host > wui-flex:first-child::-webkit-scrollbar {
    display: none;
  }
`;var u=function(o,i,e,r){var n=arguments.length,t=n<3?i:r===null?r=Object.getOwnPropertyDescriptor(i,e):r,l;if(typeof Reflect=="object"&&typeof Reflect.decorate=="function")t=Reflect.decorate(o,i,e,r);else for(var m=o.length-1;m>=0;m--)(l=o[m])&&(t=(n<3?l(t):n>3?l(i,e,t):l(i,e))||t);return n>3&&t&&Object.defineProperty(i,e,t),t};let p=class extends s{render(){return f`
      <wui-flex flexDirection="column" .padding=${["0","m","m","m"]} gap="s">
        <w3m-activity-list page="activity"></w3m-activity-list>
      </wui-flex>
    `}};p.styles=d;p=u([a("w3m-transactions-view")],p);export{p as W3mTransactionsView};
