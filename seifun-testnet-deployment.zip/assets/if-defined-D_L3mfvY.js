import{E as r}from"./state-pA-L5z5-.js";/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const m=o=>o??r;export{m as o};
